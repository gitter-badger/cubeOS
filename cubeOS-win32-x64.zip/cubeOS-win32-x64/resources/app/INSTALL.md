## Downloads
### macOS:
[Download](https://github.com/rocketbear27/cubeOS/archive/master.zip)

**Instructions**: 
1. Download
2. Extract Files

### Windows x64 
[Download](https://github.com/rocketbear27/cubeOS/archive/master.zip)

**Instructions**:
1. Download
2. Extract Files
3. Open `/cubeOS-win32-x64`
4. Run `cubeOS.exe`

### Linux x64
[Download](https://github.com/rocketbear27/cubeOS/archive/master.zip) 

**Instructions**: 
1. Download
2. 
